﻿using System;
using System.Collections.Generic;
using DAL.Models;
using Microsoft.EntityFrameworkCore;

namespace DAL.Data;

public partial class LinqdbContext : DbContext
{
    public LinqdbContext()
    {
    }

    public LinqdbContext(DbContextOptions<LinqdbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<TblCity> TblCities { get; set; }

    public virtual DbSet<TblCountry> TblCountries { get; set; }

    public virtual DbSet<TblCustomer> TblCustomers { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseSqlServer("Server=tcp:DESKTOP-9AT0AIV;Initial Catalog=LINQDb;Persist Security Info=False;User ID=sa;Password=SimpleStore2024+;MultipleActiveResultSets=False; Encrypt=True;TrustServerCertificate=True;Connection Timeout=30;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.UseCollation("Arabic_100_CI_AI");

        modelBuilder.Entity<TblCity>(entity =>
        {
            entity.HasKey(e => e.CityId);

            entity.ToTable("tblCities");

            entity.HasOne(d => d.IdCountryNavigation).WithMany(p => p.TblCities)
                .HasForeignKey(d => d.IdCountry)
                .HasConstraintName("FK_tblCities_tblCountries");
        });

        modelBuilder.Entity<TblCountry>(entity =>
        {
            entity.HasKey(e => e.CountryId);

            entity.ToTable("tblCountries");
        });

        modelBuilder.Entity<TblCustomer>(entity =>
        {
            entity.HasKey(e => e.CutomerId);

            entity.ToTable("tblCustomers");

            entity.Property(e => e.CostomerMobileNo).HasMaxLength(50);
            entity.Property(e => e.RegisterDate).HasColumnType("datetime");

            entity.HasOne(d => d.IdCityNavigation).WithMany(p => p.TblCustomers)
                .HasForeignKey(d => d.IdCity)
                .HasConstraintName("FK_tblCustomers_tblCities");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
