﻿using System;
using System.Collections.Generic;

namespace DAL.Models;

public partial class TblCustomer
{
    public int CutomerId { get; set; }

    public int? CustomerCodeNo { get; set; }

    public string? CutomerName { get; set; }

    public string? CostomerMobileNo { get; set; }

    public DateTime? RegisterDate { get; set; }

    public int? IdCity { get; set; }

    public bool? IsActive { get; set; }

    public virtual TblCity? IdCityNavigation { get; set; }
}

