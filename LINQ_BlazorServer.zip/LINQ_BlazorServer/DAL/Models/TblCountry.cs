﻿using System;
using System.Collections.Generic;

namespace DAL.Models;

public partial class TblCountry
{
    public int CountryId { get; set; }

    public string? CountryName { get; set; }

    public virtual ICollection<TblCity> TblCities { get; set; } = new List<TblCity>();
}
