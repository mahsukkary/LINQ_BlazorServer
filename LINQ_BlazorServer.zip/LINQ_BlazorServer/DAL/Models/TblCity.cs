﻿using System;
using System.Collections.Generic;

namespace DAL.Models;

public partial class TblCity
{
    public int CityId { get; set; }

    public string? CitryName { get; set; }

    public int? IdCountry { get; set; }

    public virtual TblCountry? IdCountryNavigation { get; set; }

    public virtual ICollection<TblCustomer> TblCustomers { get; set; } = new List<TblCustomer>();
}
